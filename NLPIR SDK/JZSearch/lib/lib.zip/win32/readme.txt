JZSearch Win32 library
